/*Create the database*/
CREATE DATABASE[TimeTableGenerator]
GO

/*Use the database*/
USE [TimeTableGenerator]
GO

/*Tables for the databse*/

CREATE TABLE Lecturer(
	LecturerID int IDENTITY (1,1) PRIMARY KEY NOT NULL,
	Firstname varchar(50) NOT NULL,
	Surname varchar(50) NOT NULL,
	Gender varchar(10) NOT NULL,
	BirthDay datetime NOT NULL,
	DateOfEmployment datetime NOT NULL,
	Address varchar(50) NOT NULL,
	Username varchar(25) NOT NULL,
	LecturerPassword varchar(25) NOT NULL)
GO

CREATE TABLE Subject(
	SubjectCode varchar(10) PRIMARY KEY NOT NULL,
	SubjectName varchar(20) NOT NULL,
	LecurerID int FOREIGN KEY REFERENCES Lecturer(LecturerID),
	StudentNum int NOT NULL,
	Hours int NOT NULL)
GO

CREATE TABLE Venue(
	VenueID int IDENTITY (1,1) PRIMARY KEY NOT NULL,
	CampusName varchar(50) NOT NULL,
	Address varchar(50) NOT NULL,
	BuildingName varchar(30) NOT NULL,
	SpecialFacilities varchar(50) NOT NULL,
	ClassroomNum varchar(20) NOT NULL,
	StudentCapacity int NOT NULL)
GO

CREATE TABLE Program(
	ProgramID INT IDENTITY (1,1) PRIMARY KEY NOT NULL,
	CourseID varchar(10) NOT NULL,
	SubjectID varchar(10) NOT NULL,
	SubjectDuration varchar(10) NOT NULL,
	SpecialRequirments varchar(10) NOT NULL,
	LecurerID int FOREIGN KEY REFERENCES Lecturer(LecturerID))
GO

/*Lecturer Stored Procedures*/

CREATE PROCEDURE GetLecturer
	@LecutererID int
AS
	SELECT * FROM dbo.Lecturer
	WHERE Lecturer.LecturerID = @LecutererID
GO

CREATE PROCEDURE InsertLecturer
	@LecturerID int,
	@Firstname varchar(50),
	@Surname varchar(50),
	@Gender varchar(10),
	@Birthday datetime,
	@DateOfEmployment datetime,
	@Address varchar(50),
	@Username varchar(25),
	@LecturerPassword varchar(25)
AS
	INSERT INTO dbo.Lecturer(
		LecturerID,
		FirstName,
		Surname,
		Gender,
		BirthDay,
		DateOfEmployment,
		Address,
		Username,
		LecturerPassword)
	VALUES
		(@LecturerID, @Firstname, @Surname, @Gender, @Birthday, @DateOfEmployment, @Address, @Username, @LecturerPassword)
GO

CREATE PROCEDURE UpdateLecturer
	@LecturerID int,
	@Firstname varchar(50),
	@Surname varchar(50),
	@Gender varchar(10),
	@Birthday datetime,
	@DateOfEmployment datetime,
	@Address varchar(50),
	@Username varchar(25),
	@LecturerPassword varchar(25)
AS
	UPDATE dbo.Lecturer
	SET
		Firstname=@Firstname,
		Surname=@Surname,
		Gender=@Gender,
		BirthDay=@Birthday,
		DateOfEmployment=@DateOfEmployment,
		Address=@Address,
		Username=@Username,
		LecturerPassword=@LecturerPassword
	WHERE LecturerID=@LecturerID
GO

CREATE PROCEDURE DeleteLecturer
	@LecturerID int
AS
	DELETE FROM dbo.Lecturer
	WHERE LecturerID=@LecturerID
GO
	
/*Subject Stored Procedures*/
CREATE PROCEDURE GetSubject
	@SubjectCode varchar(10)
AS
	SELECT * FROM dbo.Subject
	WHERE Subject.SubjectCode = @SubjectCode
GO

CREATE PROCEDURE InsertSubject
	@SubjectCode varchar(10),
	@SubjectName varchar(20),
	@Lecturer int,
	@StudentNum int,
	@Hours int
AS
	INSERT INTO dbo.Subject(
		SubjectCode,
		SubjectName,
		Lecturer,
		StudentNum,
		Hours)
	VALUES
		(@SubjectCode, @SubjectName, @Lecturer, @StudentNum, @Hours)
GO

CREATE PROCEDURE UpdateSubject
	@SubjectCode varchar(10),
	@SubjectName varchar(20),
	@Lecturer int,
	@StudentNum int,
	@Hours int
AS
	UPDATE dbo.Subject
	SET
		SubjectName=@SubjectName,
		Lecturer=@Lecturer,
		StudentNum=@StudentNum,
		Hours=@Hours
	WHERE SubjectCode=@SubjectCode
GO

CREATE PROCEDURE DeleteSubject
	@SubjectCode varchar(10)
AS
	DELETE FROM dbo.Subject
	WHERE SubjectCode=@SubjectCode
GO

/*Venue Stored Procedures*/

CREATE PROCEDURE GetVenue
	@VenueID int
AS
	SELECT * FROM dbo.Venue
	WHERE Venue.VenueID = @VenueID
GO

CREATE PROCEDURE InsertVenue
	@VenueID int,
	@CampusName varchar(50),
	@Address varchar(50),
	@BuildingName varchar(30),
	@SpecialFacilities varchar(50),
	@ClassroomNum varchar(20),
	@StudentCapacity int

AS
	INSERT INTO dbo.Venue(
		VenueID,
		CampusName,
		Address,
		BuildingName,
		SpecialFacilities,
		ClassroomNum,
		StudentCapacity)
	VALUES
		(@VenueID, @CampusName, @Address, @BuildingName, @SpecialFacilities, @ClassroomNum, @StudentCapacity)
GO

CREATE PROCEDURE UpdateVenue
	@VenueID int,
	@CampusName varchar(50),
	@Address varchar(50),
	@BuildingName varchar(30),
	@SpecialFacilities varchar(50),
	@ClassroomNum varchar(20),
	@StudentCapacity int
AS
	UPDATE dbo.Venue
	SET
		CampusName=@CampusName,
		Address=@Address,
		BuildingName=@BuildingName,
		SpecialFacilities=@SpecialFacilities,
		ClassroomNum=@ClassroomNum,
		StudentCapacity=@StudentCapacity
	WHERE VenueID=@VenueID
GO

CREATE PROCEDURE DeleteVenue
	@VenueID int
AS
	DELETE FROM dbo.Venue
	WHERE VenueID=@VenueID
GO
	

/* Program Stored Procedures*/

CREATE PROCEDURE GetProgram
	@ProgramID int
AS
	SELECT * FROM dbo.Program
	WHERE Program.ProgramID = @ProgramID
GO

CREATE PROCEDURE InsertProgram
	@ProgramID INT,
	@CourseID varchar(10),
	@SubjectID varchar(10),
	@SubjectDuration varchar(10),
	@SpecialRequirments varchar(10),
	@LecurerID int

AS
	INSERT INTO dbo.Program(
		ProgramID,
		CourseID,
		SubjectID,
		SubjectDuration,
		SpecialRequirments,
		LecurerID)
	VALUES
		(@ProgramID, @CourseID, @SubjectID, @SubjectDuration, @SpecialRequirments, @LecurerID)
GO

CREATE PROCEDURE UpdateProgram
	@ProgramID int,
	@CourseID varchar(10),
	@SubjectID varchar(10),
	@SubjectDuration varchar(10),
	@SpecialRequirments varchar(10),
	@LecurerID int
AS
	UPDATE dbo.Program
	SET
		CourseID=@CourseID,
		SubjectID=@SubjectID,
		SubjectDuration=@SubjectDuration,
		SpecialRequirments=@SpecialRequirments
	WHERE ProgramID=@ProgramID
GO

CREATE PROCEDURE DeleteProgram
		@ProgramID int
	AS
		DELETE FROM dbo.Program
		WHERE ProgramID=@ProgramID
GO