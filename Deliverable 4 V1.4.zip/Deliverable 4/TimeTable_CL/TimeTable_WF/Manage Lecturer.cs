﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TimeTable_WF
{
    public partial class Manage_Lecturer : Form
    {
        public Manage_Lecturer()
        {
            InitializeComponent();
        }

        ServiceReference1.Service1Client LecturerService;

        private void Manage_Lecturer_Load(object sender, EventArgs e)
        {
            LecturerService = new ServiceReference1.Service1Client();

            dgvLecturer.DataSource = LecturerService.GetLecturer();
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            Add_Lecturer aAddLec = new Add_Lecturer();
            aAddLec.ShowDialog();
        }

        private void btnEdit_Click(object sender, EventArgs e)
        {
            Edit_Lecturer aEditLec = new Edit_Lecturer();
            aEditLec.ShowDialog();
        }

        private void btnDisable_Click(object sender, EventArgs e)
        {
            try
            {
                int iLecturerID = Convert.ToInt32(dgvLecturer["Lecturer ID", dgvLecturer.CurrentCell.RowIndex].Value.ToString());
                string sName = dgvLecturer["Name", dgvLecturer.CurrentCell.RowIndex].Value.ToString();
                string sSurname = dgvLecturer["Surname", dgvLecturer.CurrentCell.RowIndex].Value.ToString();
                string sGender = dgvLecturer["Gender", dgvLecturer.CurrentCell.RowIndex].Value.ToString();
               // DateTime dtBirthdate = dgvLecturer["Subject Name", dgvLecturer.CurrentCell.RowIndex].Value.ToString();
               // DateTime dtDOE = dgvLecturer["Subject Name", dgvLecturer.CurrentCell.RowIndex].Value.ToString();
                string sAddress = dgvLecturer["Address", dgvLecturer.CurrentCell.RowIndex].Value.ToString();

                string message = "You are about to delete a Lecturer record with the following details: \n\n" + "Lecturer ID: " + iLecturerID.ToString() + "Name: " + sName.ToString() + "Surname: " + sSurname.ToString() + "Gender: " + sGender.ToString() + "Address: " + sAddress.ToString() + "\n\nAre you sure you want to?";

                DialogResult dr = new DialogResult();
                dr = MessageBox.Show(message, "Delete Lecturer Warning", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);

                if (dr == DialogResult.Yes)
                {
                   // LecturerService.DeleteLecturer(iLecturerID, sName, sSurname, sGender, sAddress); MessageBox.Show("Lecturer deleted.");
                    LecturerService = new ServiceReference1.Service1Client();
                    dgvLecturer.DataSource = LecturerService.GetLecturer();
                }
                else
                {
                    MessageBox.Show("Subject not deleted.");
                }
            }
            catch (Exception ex)
            {

            }
        }

        private void btnReturn_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
