﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TimeTable_WF
{
    public partial class Main_Menu : Form
    {
        public Main_Menu()
        {
            InitializeComponent();
        }

        private void btnSubjectInfo_Click(object sender, EventArgs e)
        {
            Subject_Management aSubInfo = new Subject_Management();
            aSubInfo.ShowDialog();
        }

        private void btnCreateTT_Click(object sender, EventArgs e)
        {
            Manage_Lecturer aManageLec = new Manage_Lecturer();
            aManageLec.ShowDialog();
        }

        private void btnViewTT_Click(object sender, EventArgs e)
        {
            View_TimeTable aViewTT = new View_TimeTable();
            aViewTT.ShowDialog();
        }

        private void btnManageVenues_Click(object sender, EventArgs e)
        {
            Venue_Management aVenueManage = new Venue_Management();
            aVenueManage.ShowDialog();
        }

        private void btnAccManagement_Click(object sender, EventArgs e)
        {
            Account_Management aAccManage = new Account_Management();
            aAccManage.ShowDialog();
        }

        private void btnLogOut_Click(object sender, EventArgs e)
        {
            LogIn aLogin = new LogIn();
            aLogin.ShowDialog();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
