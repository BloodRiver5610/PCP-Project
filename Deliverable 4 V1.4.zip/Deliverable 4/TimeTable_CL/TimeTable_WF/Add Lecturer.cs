﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TimeTable_WF
{
    public partial class Add_Lecturer : Form
    {
        public Add_Lecturer()
        {
            InitializeComponent();
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            try
            {
                string sLectureID = txtID.Text;
                string sName = txtName.Text;
                string sSurname = txtSurname.Text;
                //string sGender = cbNumStudents.;
                //DateTime dtBirthDate = dtpBirthDate.;
                //DateTime dtDOE = dtpDOE.;
                string sAddress = txtAddress.Text;

                // aSubjectService.AddLecturer(sLecturerID, sName, sSurename, sGender, dtBirthDate, dtDOE, sAddress);

                MessageBox.Show("New Lecturer was successfully added.", "New Lecturer Added", MessageBoxButtons.OK, MessageBoxIcon.Information);

                this.Validate();
                this.DialogResult = DialogResult.OK;
                this.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("New Lecturer details could not be added.", "New Lecturer Added - Failed", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
