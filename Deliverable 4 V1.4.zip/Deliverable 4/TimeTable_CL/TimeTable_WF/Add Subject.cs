﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TimeTable_WF
{
    public partial class Add_Subject : Form
    {
        public Add_Subject()
        {
            InitializeComponent();
        }

        private ServiceReference1.Service1Client aSubjectService = new ServiceReference1.Service1Client();

        private void btnSave_Click(object sender, EventArgs e)
        {
            try
            {
                string sSubjectCode = txtCode.Text;
                string sName = txtName.Text;
                string sLecturer = txtLecturer.Text;
                string sNumofStudents = cbNumStudents.Text;
                string sHours = cbHours.Text;

                // aSubjectService.AddSubject(sSubjectCode, sName, sLecturer, sNumofStudents, sHours);

                MessageBox.Show("New Subject was successfully added.", "New Subject Added", MessageBoxButtons.OK, MessageBoxIcon.Information);

                this.Validate();
                this.DialogResult = DialogResult.OK;
                this.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("New Subject details could not be added.", "New Subject Added - Failed", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
