﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TimeTable_WF
{
    public partial class Account_Management : Form
    {
        public Account_Management()
        {
            InitializeComponent();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        ServiceReference1.Service1Client LecturerService;

        private void Account_Management_Load(object sender, EventArgs e)
        {
            LecturerService = new ServiceReference1.Service1Client();

            dgvAccount.DataSource = LecturerService.GetLecturer();
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            Add_Account aAddAcc = new Add_Account();
            aAddAcc.ShowDialog();
        }

        private void btnEdit_Click(object sender, EventArgs e)
        {
            Edit_Account aEditAcc = new Edit_Account();
            aEditAcc.ShowDialog();
        }

        private void btnDisable_Click(object sender, EventArgs e)
        {
            try
            {
                string sUserName = dgvAccount["Name", dgvAccount.CurrentCell.RowIndex].Value.ToString();
                string sPassword = dgvAccount["Surname", dgvAccount.CurrentCell.RowIndex].Value.ToString();
                string sLevel = dgvAccount["Gender", dgvAccount.CurrentCell.RowIndex].Value.ToString();

                string message = "You are about to delete a Account record with the following details: \n\n" + "Username: " + sUserName.ToString() + "Account Level: " + sLevel.ToString() + "\n\nAre you sure you want to?";

                DialogResult dr = new DialogResult();
                dr = MessageBox.Show(message, "Delete Account Warning", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);

                if (dr == DialogResult.Yes)
                {
                    // LecturerService.DeleteLecturer(iLecturerID, sName, sSurname, sGender, sAddress); MessageBox.Show("Lecturer deleted.");
                    LecturerService = new ServiceReference1.Service1Client();
                    dgvAccount.DataSource = LecturerService.GetLecturer();
                }
                else
                {
                    MessageBox.Show("Subject not deleted.");
                }
            }
            catch (Exception ex)
            {

            }
        }

        private void btnReturn_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
