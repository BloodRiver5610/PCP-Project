﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TimeTable_WF
{
    public partial class Add_Account : Form
    {
        public Add_Account()
        {
            InitializeComponent();
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            try
            {
                string sUserName = txtUserName.Text;
                string sPassword = txtPassword.Text;
                string sLevel = cbLevel.Text;

                //aSubjectService.AddLecturer(sUserName, sPassword, sLevel);

                MessageBox.Show("New account was successfully added.", "New account Added", MessageBoxButtons.OK, MessageBoxIcon.Information);

                this.Validate();
                this.DialogResult = DialogResult.OK;
                this.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("New account details could not be added.", "New account Added - Failed", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
