﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TimeTable_WF
{
    public partial class Subject_Management : Form
    {
        public Subject_Management()
        {
            InitializeComponent();
        }

        ServiceReference1.Service1Client SubjectService;

        private void Subject_Management_Load(object sender, EventArgs e)
        {
            SubjectService = new ServiceReference1.Service1Client();

            dgvSubjects.DataSource = SubjectService.GetSubjects();
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            Add_Subject aAddSub = new Add_Subject();
            aAddSub.ShowDialog();
        }

        private void btnEdit_Click(object sender, EventArgs e)
        {
            Edit_Subject aEditSub = new Edit_Subject();
            aEditSub.ShowDialog();
        }

        private void btnDisable_Click(object sender, EventArgs e)
        {
            try
            {
                int iSubjectCode = Convert.ToInt32(dgvSubjects["Subject Code", dgvSubjects.CurrentCell.RowIndex].Value.ToString());
                string SSubjectName = dgvSubjects["Subject Name", dgvSubjects.CurrentCell.RowIndex].Value.ToString();
                int iLecturer = Convert.ToInt32(dgvSubjects["Lecturer", dgvSubjects.CurrentCell.RowIndex].Value.ToString());
                int iStudentNum = Convert.ToInt32(dgvSubjects["Number of students", dgvSubjects.CurrentCell.RowIndex].Value.ToString());
                int iHours = Convert.ToInt32(dgvSubjects["Hours", dgvSubjects.CurrentCell.RowIndex].Value.ToString());

                string message = "You are about to delete a Subject record with the following details: \n\n" + "Subject Code: " + iSubjectCode.ToString() + "Subject Name: " + SSubjectName.ToString() + "Lecturer: " + iLecturer.ToString() + "Number of students: " + iStudentNum.ToString() + "Hours: " + iHours.ToString() + "\n\nAre you sure you want to?";

                DialogResult dr = new DialogResult();
                dr = MessageBox.Show(message, "Delete Subject Warning", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);

                if (dr == DialogResult.Yes)
                {
                    SubjectService.DeleteSubject(iSubjectCode, SSubjectName, iLecturer, iStudentNum, iHours); MessageBox.Show("Subject deleted.");
                    SubjectService = new ServiceReference1.Service1Client();
                    dgvSubjects.DataSource = SubjectService.GetSubjects();
                }
                else
                {
                    MessageBox.Show("Subject not deleted.");
                }
            }
            catch (Exception ex)
            {

            }
        }

        private void btnReturn_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
