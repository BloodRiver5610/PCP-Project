﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TimeTable_CL.Classes
{
    public class Subject
    {
        public int SubjectCode { get; set; }
        public string SubjectName { get; set; }
        public int Lecturer { get; set; }
        public int StudentNum { get; set; }
        public int Hours { get; set; }

        public Subject()
        {
            this.SubjectCode = 0;
            this.SubjectName = "";
            this.Lecturer = 0;
            this.StudentNum = 0;
            this.Hours = 0;
        }

        public Subject(int subjectcode, string subjectname, int lecturer, int studentnum, int hours)
        {
            this.SubjectCode = subjectcode;
            this.SubjectName = subjectname;
            this.Lecturer = lecturer;
            this.StudentNum = studentnum;
            this.Hours = hours;
        }
    }
}
