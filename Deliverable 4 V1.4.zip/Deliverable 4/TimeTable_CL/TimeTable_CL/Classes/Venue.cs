﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TimeTable_CL.Classes
{
    public class Venue
    {
        public int VenueID{ get; set; }
        public string CampusName { get; set; }
        public string Address { get; set; }
        public string BuildingName { get; set; }
        public string SF { get; set; }
        public string ClassroomNum { get; set; }
        public int StudentCap { get; set; }

        public Venue()
        {
            this.VenueID = 0;
            this.CampusName = "";
            this.Address = "";
            this.BuildingName = "";
            this.SF = "";
            this.ClassroomNum = "";
            this.StudentCap = 0;
        }

        public Venue(int venueid, string campusname, string address, string buildingname, string sf, string classroomnum, int studentcap)
        {
            this.VenueID = venueid;
            this.CampusName = campusname;
            this.Address = address;
            this.BuildingName = buildingname;
            this.SF = sf;
            this.ClassroomNum = classroomnum;
            this.StudentCap = studentcap;
        }
    }
}
