﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel;

namespace TimeTable_CL.ClassLists
{
    public class SubjectList : BindingList<Classes.Subject>
    {
        private Dataset.TimeTable_DSTableAdapters.GetSubjectTableAdapter aSubjectAdapter = new Dataset.TimeTable_DSTableAdapters.GetSubjectTableAdapter();
        private Dataset.TimeTable_DSTableAdapters.GetLecturerTableAdapter aLecturerAdapter = new Dataset.TimeTable_DSTableAdapters.GetLecturerTableAdapter();
        private Dataset.TimeTable_DS aTableDS = new Dataset.TimeTable_DS();

        public SubjectList()
        {
            aSubjectAdapter.Fill(aTableDS.GetSubject, 0);
            aLecturerAdapter.Fill(aTableDS.GetLecturer, 0);

            foreach (Dataset.TimeTable_DS.GetSubjectRow aSubjectRow in aTableDS.GetSubject.Rows)
            {
                Classes.Subject aSubject = new Classes.Subject(aSubjectRow.SubjectCode, aSubjectRow.SubjectName, aSubjectRow.Lecturer, aSubjectRow.StudentNum, aSubjectRow.Hours);
                this.Add(aSubject);
            }
        }

        public SubjectList(int ID)
        {
            aSubjectAdapter.Fill(aTableDS.GetSubject, ID);
            aLecturerAdapter.Fill(aTableDS.GetLecturer, 0);

            foreach (Dataset.TimeTable_DS.GetSubjectRow aSubjectRow in aTableDS.GetSubject.Rows)
            {
                if (aSubjectRow.SubjectCode == ID)
                {
                    Classes.Subject aSubject = new Classes.Subject(aSubjectRow.SubjectCode, aSubjectRow.SubjectName, aSubjectRow.Lecturer, aSubjectRow.StudentNum, aSubjectRow.Hours);
                    this.Add(aSubject);
                }
            }
        }

        public void SaveSubjectChanges()
        {
            Dataset.TimeTable_DS.GetSubjectDataTable aTempSubjectTable = new Dataset.TimeTable_DS.GetSubjectDataTable();
            try
            {
                foreach (Classes.Subject aSubject in this)
                {
                    Dataset.TimeTable_DS.GetSubjectRow aNewSubjectRow = aTableDS.GetSubject.NewGetSubjectRow();

                    aNewSubjectRow.SubjectCode = aSubject.SubjectCode;
                    aNewSubjectRow.SubjectName = aSubject.SubjectName;
                    aNewSubjectRow.Lecturer = aSubject.Lecturer;
                    aNewSubjectRow.StudentNum = aSubject.StudentNum;
                    aNewSubjectRow.Hours = aSubject.Hours;

                    aTempSubjectTable.Rows.Add(aNewSubjectRow.ItemArray);
                }
                aTableDS.GetSubject.Merge(aTempSubjectTable, false);

                foreach (Dataset.TimeTable_DS.GetSubjectRow aSubjectRow in aTableDS.GetSubject.Rows)
                {
                    if (aSubjectRow.RowState == System.Data.DataRowState.Unchanged)
                    {
                        aSubjectRow.Delete();
                    }
                }
                aSubjectAdapter.Update(aTableDS.GetSubject);
            }

            catch (Exception ex)
            {

            }
        }

        public SubjectList GetSubjects()
        {
            return this;
        }

        public SubjectList GetSubject(int ID)
        {
            SubjectList tempBL = new SubjectList(ID);
            return tempBL;
        }

        public void InsertSubject(Classes.Subject insertSubject)
        {
            this.Add(insertSubject);
        }

        public void UpdateSubject(Classes.Subject updateSubject)
        {
            foreach (Classes.Subject aSubject in this)
            {
                if (aSubject.SubjectCode == updateSubject.SubjectCode)
                {
                    aSubject.SubjectName = updateSubject.SubjectName;
                    aSubject.Lecturer = updateSubject.Lecturer;
                    aSubject.StudentNum = updateSubject.StudentNum;
                    aSubject.Hours = updateSubject.Hours;
                    break;
                }
            }
        }

        public void DeleteSubject(Classes.Subject deleteSubject)
        {
            int i = 0;
            int deleteIndex = -1;

            foreach (Classes.Subject aSubject in this)
            {
                if (aSubject.SubjectCode == deleteSubject.SubjectCode)
                {
                    deleteIndex = i;
                }
                i++;
            }

            if (deleteIndex != -1)
            {
                this.RemoveAt(deleteIndex);
            }
        }
    }
}
