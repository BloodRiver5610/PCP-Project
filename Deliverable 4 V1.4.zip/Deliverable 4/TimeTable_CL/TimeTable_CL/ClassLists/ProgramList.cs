﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel;

namespace TimeTable_CL.ClassLists
{
    public class ProgramList : BindingList<Classes.Program>
    {
        private Dataset.TimeTable_DSTableAdapters.GetProgramTableAdapter aProgramAdapter = new Dataset.TimeTable_DSTableAdapters.GetProgramTableAdapter();
        private Dataset.TimeTable_DSTableAdapters.GetLecturerTableAdapter aLecturerAdapter = new Dataset.TimeTable_DSTableAdapters.GetLecturerTableAdapter();
        private Dataset.TimeTable_DS aTableDS = new Dataset.TimeTable_DS();

        public ProgramList()
        {
            aProgramAdapter.Fill(aTableDS.GetProgram, 0);
            aLecturerAdapter.Fill(aTableDS.GetLecturer, 0);

            foreach (Dataset.TimeTable_DS.GetProgramRow aProgramRow in aTableDS.GetProgram.Rows)
            {
                Classes.Program aProgram = new Classes.Program(aProgramRow.ProgramID, aProgramRow.CourseID, aProgramRow.SubjectID, aProgramRow.SubjectDuration, aProgramRow.SpecialRequirments, aProgramRow.LecurerID);
                this.Add(aProgram);
            }
        }

        public ProgramList(int ID)
        {
            aProgramAdapter.Fill(aTableDS.GetProgram, ID);
            aLecturerAdapter.Fill(aTableDS.GetLecturer, 0);

            foreach (Dataset.TimeTable_DS.GetProgramRow aProgramRow in aTableDS.GetProgram.Rows)
            {
                if (aProgramRow.ProgramID == ID)
                {
                    Classes.Program aProgram = new Classes.Program(aProgramRow.ProgramID, aProgramRow.CourseID, aProgramRow.SubjectID, aProgramRow.SubjectDuration, aProgramRow.SpecialRequirments, aProgramRow.LecurerID);
                    this.Add(aProgram);
                }
            }
        }

        public void SaveProgramChanges()
        {
            Dataset.TimeTable_DS.GetProgramDataTable aTempProgramTable = new Dataset.TimeTable_DS.GetProgramDataTable();
            try
            {
                foreach (Classes.Program aProgram in this)
                {
                    Dataset.TimeTable_DS.GetProgramRow aNewProgramRow = aTableDS.GetProgram.NewGetProgramRow();

                    aNewProgramRow.ProgramID = aProgram.ProgramID;
                    aNewProgramRow.CourseID = aProgram.CourseID;
                    aNewProgramRow.SubjectID = aProgram.SubjectID;
                    aNewProgramRow.SubjectDuration = aProgram.SubDuration;
                    aNewProgramRow.SpecialRequirments = aProgram.SpecialRequirments;
                    aNewProgramRow.LecurerID = aProgram.LecturerID;

                    aTempProgramTable.Rows.Add(aNewProgramRow.ItemArray);
                }
                aTableDS.GetProgram.Merge(aTempProgramTable, false);

                foreach (Dataset.TimeTable_DS.GetProgramRow aProgramRow in aTableDS.GetProgram.Rows)
                {
                    if (aProgramRow.RowState == System.Data.DataRowState.Unchanged)
                    {
                        aProgramRow.Delete();
                    }
                }
                aProgramAdapter.Update(aTableDS.GetProgram);
            }

            catch (Exception ex)
            {

            }
        }

        public ProgramList GetPrograms()
        {
            return this;
        }

        public ProgramList GetProgram(int ID)
        {
            ProgramList tempBL = new ProgramList(ID);
            return tempBL;
        }

        public void InsertProgram(Classes.Program insertProgram)
        {
            this.Add(insertProgram);
        }

        public void UpdateProgram(Classes.Program updateProgram)
        {
            foreach (Classes.Program aProgram in this)
            {
                if (aProgram.ProgramID == updateProgram.ProgramID)
                {
                    aProgram.CourseID = updateProgram.CourseID;
                    aProgram.SubjectID = updateProgram.SubjectID;
                    aProgram.SubDuration = updateProgram.SubDuration;
                    aProgram.SpecialRequirments = updateProgram.SpecialRequirments;
                    aProgram.LecturerID = updateProgram.LecturerID;
                    break;
                }
            }
        }

        public void DeleteProgram(Classes.Program deleteProgram)
        {
            int i = 0;
            int deleteIndex = -1;

            foreach (Classes.Program aProgram in this)
            {
                if (aProgram.ProgramID == deleteProgram.ProgramID)
                {
                    deleteIndex = i;
                }
                i++;
            }

            if (deleteIndex != -1)
            {
                this.RemoveAt(deleteIndex);
            }
        }
    }
}
