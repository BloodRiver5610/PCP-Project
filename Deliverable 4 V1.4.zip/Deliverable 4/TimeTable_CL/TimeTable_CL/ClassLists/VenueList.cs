﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel;

namespace TimeTable_CL.ClassLists
{
    public class VenueList : BindingList<Classes.Venue>
    {
        private Dataset.TimeTable_DSTableAdapters.GetVenueTableAdapter aVenueAdapter = new Dataset.TimeTable_DSTableAdapters.GetVenueTableAdapter();
        private Dataset.TimeTable_DS aTableDS = new Dataset.TimeTable_DS();

        public VenueList()
        {
            aVenueAdapter.Fill(aTableDS.GetVenue, 0);

            foreach (Dataset.TimeTable_DS.GetVenueRow aVenueRow in aTableDS.GetVenue.Rows)
            {
                Classes.Venue aVenues = new Classes.Venue(aVenueRow.VenueID, aVenueRow.CampusName, aVenueRow.Address, aVenueRow.BuildingName, aVenueRow.SpecialFacilities, aVenueRow.ClassroomNum, aVenueRow.StudentCapacity);
                this.Add(aVenues);
            }
        }

        public VenueList(int ID)
        {
            aVenueAdapter.Fill(aTableDS.GetVenue, ID);

            foreach (Dataset.TimeTable_DS.GetVenueRow aVenueRow in aTableDS.GetVenue.Rows)
            {
                if (aVenueRow.VenueID == ID)
                {
                    Classes.Venue aVenues = new Classes.Venue(aVenueRow.VenueID, aVenueRow.CampusName, aVenueRow.Address, aVenueRow.BuildingName, aVenueRow.SpecialFacilities, aVenueRow.ClassroomNum, aVenueRow.StudentCapacity);
                    this.Add(aVenues);
                }
            }
        }

        public void SaveVenuesChanges()
        {
            Dataset.TimeTable_DS.GetVenueDataTable aTempVenuesTable = new Dataset.TimeTable_DS.GetVenueDataTable();
            try
            {
                foreach (Classes.Venue aVenues in this)
                {
                    Dataset.TimeTable_DS.GetVenueRow aNewVenuesRow = aTableDS.GetVenue.NewGetVenueRow();

                    aNewVenuesRow.VenueID = aVenues.VenueID;
                    aNewVenuesRow.CampusName = aVenues.CampusName;
                    aNewVenuesRow.Address = aVenues.Address;
                    aNewVenuesRow.BuildingName = aVenues.BuildingName;
                    aNewVenuesRow.SpecialFacilities = aVenues.SF;
                    aNewVenuesRow.ClassroomNum = aVenues.ClassroomNum;
                    aNewVenuesRow.StudentCapacity = aVenues.StudentCap;

                    aTempVenuesTable.Rows.Add(aNewVenuesRow.ItemArray);
                }
                aTableDS.GetVenue.Merge(aTempVenuesTable, false);

                foreach (Dataset.TimeTable_DS.GetVenueRow aVenuesRow in aTableDS.GetVenue.Rows)
                {
                    if (aVenuesRow.RowState == System.Data.DataRowState.Unchanged)
                    {
                        aVenuesRow.Delete();
                    }
                }
                aVenueAdapter.Update(aTableDS.GetVenue);
            }

            catch (Exception ex)
            {

            }
        }

        public VenueList GetVenuess()
        {
            return this;
        }

        public VenueList GetVenues(int ID)
        {
            VenueList tempBL = new VenueList(ID);
            return tempBL;
        }

        public void InsertVenues(Classes.Venue insertVenues)
        {
            this.Add(insertVenues);
        }

        public void UpdateVenues(Classes.Venue updateVenues)
        {
            foreach (Classes.Venue aVenues in this)
            {
                if (aVenues.VenueID == updateVenues.VenueID)
                {
                    aVenues.CampusName = updateVenues.CampusName;
                    aVenues.Address = updateVenues.Address;
                    aVenues.BuildingName = updateVenues.BuildingName;
                    aVenues.SF = updateVenues.SF;
                    aVenues.ClassroomNum = updateVenues.ClassroomNum;
                    aVenues.StudentCap = updateVenues.StudentCap;
                    break;
                }
            }
        }

        public void DeleteVenues(Classes.Venue deleteVenues)
        {
            int i = 0;
            int deleteIndex = -1;

            foreach (Classes.Venue aVenues in this)
            {
                if (aVenues.VenueID == deleteVenues.VenueID)
                {
                    deleteIndex = i;
                }
                i++;
            }

            if (deleteIndex != -1)
            {
                this.RemoveAt(deleteIndex);
            }
        }
    }
}
