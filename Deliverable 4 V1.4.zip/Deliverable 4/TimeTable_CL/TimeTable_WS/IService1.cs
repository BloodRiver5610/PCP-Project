﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Text;

namespace TimeTable_WS
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the interface name "IService1" in both code and config file together.
    [ServiceContract]
    public interface IService1
    {

        [OperationContract]
        string GetData(int value);

        [OperationContract]
        CompositeType GetDataUsingDataContract(CompositeType composite);

        // TODO: Add your service operations here
        #region Lecturer Operation Contracts

        [OperationContract]
        TimeTable_CL.ClassLists.LecturerList GetLecturer();
        [OperationContract]
        void AddLecturer(string FirstName, string SurName, string Gender, DateTime BirthDate, DateTime DOE, string Address, string Username, string Password);
        [OperationContract]
        void UpdateLecturer(int LecturerID, string FirstName, string SurName, string Gender, DateTime BirthDate, DateTime DOE, string Address, string Username, string Password);
        [OperationContract]
        void DeleteLecturer(int LecturerID, string FirstName, string SurName, string Gender, DateTime BirthDate, DateTime DOE, string Address, string Username, string Password);

        #endregion

        #region Subject Operation Contracts

        [OperationContract]
        TimeTable_CL.ClassLists.SubjectList GetSubjects();
        [OperationContract]
        void AddSubject(string SubjectName, int Lecturer, int StudentNum, int Hours);
        [OperationContract]
        void UpdateSubject(int SubjectCode, string SubjectName, int Lecturer, int StudentNum, int Hours);
        [OperationContract]
        void DeleteSubject(int SubjectCode, string SubjectName, int Lecturer, int StudentNum, int Hours);

        #endregion

        #region Program Operation Contracts

        [OperationContract]
        TimeTable_CL.ClassLists.ProgramList GetProgram();
        [OperationContract]
        void AddProgram(string CourseID, string SubjectID, string SubDuration, string SpecialRequirments, int LecturerID);
        [OperationContract]
        void UpdateProgram(int ProgramID, string CourseID, string SubjectID, string SubDuration, string SpecialRequirments, int LecturerID);
        [OperationContract]
        void DeleteProgram(int ProgramID, string CourseID, string SubjectID, string SubDuration, string SpecialRequirments, int LecturerID);

        #endregion

        #region Venue Operation Contracts

        [OperationContract]
        TimeTable_CL.ClassLists.VenueList GetVenue();
        [OperationContract]
        void AddVenue(string Campusname, string Address, string BuildingName, string SF, string Classroomnum, int StudentCap);
        [OperationContract]
        void UpdateVenue(int VenueID, string Campusname, string Address, string BuildingName, string SF, string Classroomnum, int StudentCap);
        [OperationContract]
        void DeleteVenue(int VenueID, string Campusname, string Address, string BuildingName, string SF, string Classroomnum, int StudentCap);

        #endregion
    }
    

    // Use a data contract as illustrated in the sample below to add composite types to service operations.
    [DataContract]
    public class CompositeType
    {
        bool boolValue = true;
        string stringValue = "Hello ";

        [DataMember]
        public bool BoolValue
        {
            get { return boolValue; }
            set { boolValue = value; }
        }

        [DataMember]
        public string StringValue
        {
            get { return stringValue; }
            set { stringValue = value; }
        }
    }
}
