﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel;

namespace TimeTable_CL.ClassLists
{
    public class LecturerList : BindingList<Classes.Lecturer>
    {
        private Dataset.TimeTable_DSTableAdapters.GetLecturerTableAdapter aLecturerAdapter = new Dataset.TimeTable_DSTableAdapters.GetLecturerTableAdapter();
        private Dataset.TimeTable_DS aTableDS = new Dataset.TimeTable_DS();

        public LecturerList()
        {
            aLecturerAdapter.Fill(aTableDS.GetLecturer, 0);

            foreach (Dataset.TimeTable_DS.GetLecturerRow aLecturerRow in aTableDS.GetLecturer.Rows)
            {
                Classes.Lecturer aLecturer = new Classes.Lecturer(aLecturerRow.LecturerID, aLecturerRow.FirstName, aLecturerRow.Surname, aLecturerRow.Gender, aLecturerRow.BirthDay, aLecturerRow.DateOfEmployment, aLecturerRow.Address, aLecturerRow.Username, aLecturerRow.LecturerPassword);
                this.Add(aLecturer);
            }
        }

        public LecturerList(int ID)
        {
            aLecturerAdapter.Fill(aTableDS.GetLecturer, ID);

            foreach (Dataset.TimeTable_DS.GetLecturerRow aLecturerRow in aTableDS.GetLecturer.Rows)
            {
                if (aLecturerRow.LecturerID == ID)
                {
                    Classes.Lecturer aLecturer = new Classes.Lecturer(aLecturerRow.LecturerID, aLecturerRow.FirstName, aLecturerRow.Surname, aLecturerRow.Gender, aLecturerRow.BirthDay, aLecturerRow.DateOfEmployment, aLecturerRow.Address, aLecturerRow.Username, aLecturerRow.LecturerPassword);
                    this.Add(aLecturer);
                }
            }
        }

        public void SaveLecurerChanges()
        {
            Dataset.TimeTable_DS.GetLecturerDataTable aTempLecturerTable = new Dataset.TimeTable_DS.GetLecturerDataTable();
            try
            {
                foreach (Classes.Lecturer aLecturer in this)
                {
                    Dataset.TimeTable_DS.GetLecturerRow aNewLecturerRow = aTableDS.GetLecturer.NewGetLecturerRow();

                    aNewLecturerRow.LecturerID = aLecturer.LecturerID;
                    aNewLecturerRow.FirstName = aLecturer.FirstName;
                    aNewLecturerRow.Surname = aLecturer.SurName;
                    aNewLecturerRow.Gender = aLecturer.Gender;
                    aNewLecturerRow.BirthDay = aLecturer.BirthDate;
                    aNewLecturerRow.DateOfEmployment = aLecturer.DOE;
                    aNewLecturerRow.Address = aLecturer.Address;
                    aNewLecturerRow.Username = aLecturer.UserName;
                    aNewLecturerRow.LecturerPassword = aLecturer.Password;

                    aTempLecturerTable.Rows.Add(aNewLecturerRow.ItemArray);
                }
                aTableDS.GetLecturer.Merge(aTempLecturerTable, false);

                foreach (Dataset.TimeTable_DS.GetLecturerRow aLecturerRow in aTableDS.GetLecturer.Rows)
                {
                    if (aLecturerRow.RowState == System.Data.DataRowState.Unchanged)
                    {
                        aLecturerRow.Delete();
                    }
                }
                aLecturerAdapter.Update(aTableDS.GetLecturer);
            }

            catch (Exception ex)
            {

            }
        }

        public LecturerList GetLecturer()
        {
            return this;
        }

        public LecturerList GetLecturer(int ID)
        {
            LecturerList tempBL = new LecturerList(ID);
            return tempBL;
        }

        public void InsertLecturer(Classes.Lecturer insertLecturer)
        {
            this.Add(insertLecturer);
        }

        public void UpdateLecturer(Classes.Lecturer updateLecturer)
        {
            foreach (Classes.Lecturer aLecturer in this)
            {
                if (aLecturer.LecturerID == updateLecturer.LecturerID)
                {
                    aLecturer.FirstName = updateLecturer.FirstName;
                    aLecturer.SurName = updateLecturer.SurName;
                    aLecturer.Gender = updateLecturer.Gender;
                    aLecturer.BirthDate = updateLecturer.BirthDate;
                    aLecturer.DOE = updateLecturer.DOE;
                    aLecturer.Address = updateLecturer.Address;
                    aLecturer.UserName = updateLecturer.UserName;
                    aLecturer.Password = updateLecturer.Password;
                    break;
                }
            }
        }

        public void DeleteLecturer(Classes.Lecturer deleteLecturer)
        {
            int i = 0;
            int deleteIndex = -1;

            foreach (Classes.Lecturer aLecturer in this)
            {
                if (aLecturer.LecturerID == deleteLecturer.LecturerID)
                {
                    deleteIndex = i;
                }
                i++;
            }

            if (deleteIndex != -1)
            {
                this.RemoveAt(deleteIndex);
            }
        }
    }
}
