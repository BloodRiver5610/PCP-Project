﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TimeTable_CL.Classes
{
    public class Lecturer
    {
        public int LecturerID { get; set; }
        public string FirstName { get; set; }
        public string SurName { get; set; }
        public string Gender { get; set; }
        public DateTime BirthDate { get; set; }
        public DateTime DOE { get; set; }
        public string Address { get; set; }
        public string UserName { get; set; }
        public string Password { get; set; }

        public Lecturer()
        {
            this.LecturerID = 0;
            this.FirstName = "";
            this.SurName = "";
            this.Gender = "";
            this.BirthDate = DateTime.Now;
            this.DOE = DateTime.Now;
            this.Address = "";
            this.UserName = "";
            this.Password = "";
        }

        public Lecturer(int lecturerid, string firstname, string surname, string gender, DateTime birthdate, DateTime doe, string address, string username, string password)
        {
            this.LecturerID = lecturerid;
            this.FirstName = firstname;
            this.SurName = surname;
            this.Gender = gender;
            this.BirthDate = birthdate;
            this.DOE = doe;
            this.Address = address;
            this.UserName = username;
            this.Password = password;
        }
    }
}
