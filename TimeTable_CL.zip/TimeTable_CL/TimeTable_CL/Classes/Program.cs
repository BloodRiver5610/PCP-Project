﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TimeTable_CL.Classes
{
    public class Program
    {
        public int ProgramID { get; set; }
        public string CourseID { get; set; }
        public string SubjectID { get; set; }
        public string SubDuration { get; set; }
        public string SpecialRequirments { get; set; }
        public int LecturerID { get; set; }

        public Program()
        {
            this.ProgramID = 0;
            this.CourseID = "";
            this.SubjectID = "";
            this.SubDuration = "";
            this.SpecialRequirments = "";
            this.LecturerID = 0;
        }

        public Program(int programid, string courseid, string subjectid, string subduration, string specialrequirments, int lecturerid)
        {
            this.ProgramID = programid;
            this.CourseID = courseid;
            this.SubjectID = subjectid;
            this.SubDuration = subduration;
            this.SpecialRequirments = specialrequirments;
            this.LecturerID = lecturerid;
        }
    }
}
