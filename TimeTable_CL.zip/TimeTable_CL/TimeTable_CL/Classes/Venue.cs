﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TimeTable_CL.Classes
{
    public class Venue
    {
        public int VenueID{ get; set; }
        public string SF { get; set; }
        public int StudentCap { get; set; }

        public Venue()
        {
            this.VenueID = 0;
            this.SF = "";
            this.StudentCap = 0;
        }

        public Venue(int venueid, string sf, int studentcap)
        {
            this.VenueID = venueid;
            this.SF = sf;
            this.StudentCap = studentcap;
        }
    }
}
