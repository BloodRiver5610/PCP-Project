﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Text;

namespace TimeTable_WS
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the class name "Service1" in code, svc and config file together.
    // NOTE: In order to launch WCF Test Client for testing this service, please select Service1.svc or Service1.svc.cs at the Solution Explorer and start debugging.
    public class Service1 : IService1
    {
        #region Variables

        private TimeTable_CL.ClassLists.LecturerList LL = new TimeTable_CL.ClassLists.LecturerList();
        private TimeTable_CL.ClassLists.ProgramList PL = new TimeTable_CL.ClassLists.ProgramList();
        private TimeTable_CL.ClassLists.VenueList VL = new TimeTable_CL.ClassLists.VenueList();

        #endregion

        #region Lecturer Methods and Functions

        public TimeTable_CL.ClassLists.LecturerList GetLecturer()
        {
            try
            {
                LL = new TimeTable_CL.ClassLists.LecturerList();

                return LL;
            }
            catch (Exception ex) { return null; }
        }

        public void AddLecturer(int LecturerID, string FirstName, string SurName, string Gender, DateTime BirthDate, DateTime DOE, string Address, string Username, string Password)
        {
            try
            {
                LL = new TimeTable_CL.ClassLists.LecturerList();
                TimeTable_CL.Classes.Lecturer aNewLecturer = new TimeTable_CL.Classes.Lecturer(0, FirstName, SurName, Gender, BirthDate, DOE, Address, Username, Password);
                LL.InsertLecturer(aNewLecturer);

                LL.SaveLecurerChanges();
            }
            catch (Exception ex)
            {

            }
        }

        public void UpdateLecturer(int LecturerID, string FirstName, string SurName, string Gender, DateTime BirthDate, DateTime DOE, string Address, string Username, string Password)
        {
            try
            {
                LL = new TimeTable_CL.ClassLists.LecturerList();
                TimeTable_CL.Classes.Lecturer aUpdateLecturer = new TimeTable_CL.Classes.Lecturer(LecturerID, FirstName, SurName, Gender, BirthDate, DOE, Address, Username, Password);
                LL.UpdateLecturer(aUpdateLecturer);

                LL.SaveLecurerChanges();
            }
            catch (Exception ex)
            {

            }
        }

        public void DeleteLecturer(int LecturerID, string FirstName, string SurName, string Gender, DateTime BirthDate, DateTime DOE, string Address, string Username, string Password)
        {
            TimeTable_CL.Classes.Lecturer aDeleteLecturer = new TimeTable_CL.Classes.Lecturer(LecturerID, FirstName, SurName, Gender, BirthDate, DOE, Address, Username, Password);

            LL.DeleteLecturer(aDeleteLecturer);
        }

        #endregion

        #region Program Methods and Functions

        public TimeTable_CL.ClassLists.ProgramList GetProgram()
        {
            try
            {
                PL = new TimeTable_CL.ClassLists.ProgramList();

                return PL;
            }
            catch (Exception ex) { return null; }
        }

        public void AddProgram(int ProgramID, string CourseID, string SubjectID, string SubDuration, string SpecialRequirments, int LecturerID)
        {
            try
            {
                PL = new TimeTable_CL.ClassLists.ProgramList();
                TimeTable_CL.Classes.Program aNewProgram = new TimeTable_CL.Classes.Program(ProgramID, CourseID, SubjectID, SubDuration, SpecialRequirments, LecturerID);
                PL.InsertProgram(aNewProgram);

                PL.SaveProgramChanges();
            }
            catch (Exception ex)
            {

            }
        }

        public void UpdateProgram(int ProgramID, string CourseID, string SubjectID, string SubDuration, string SpecialRequirments, int LecturerID)
        {
            try
            {
                PL = new TimeTable_CL.ClassLists.ProgramList();
                TimeTable_CL.Classes.Program aUpdateProgram = new TimeTable_CL.Classes.Program(ProgramID, CourseID, SubjectID, SubDuration, SpecialRequirments, LecturerID);
                PL.UpdateProgram(aUpdateProgram);

                PL.SaveProgramChanges();
            }
            catch (Exception ex)
            {

            }
        }

        public void DeleteProgram(int ProgramID, string CourseID, string SubjectID, string SubDuration, string SpecialRequirments, int LecturerID)
        {
            TimeTable_CL.Classes.Program aDeleteProgram = new TimeTable_CL.Classes.Program(ProgramID, CourseID, SubjectID, SubDuration, SpecialRequirments, LecturerID);

            PL.DeleteProgram(aDeleteProgram);
        }

        #endregion

        #region Venue Methods and Functions

        public TimeTable_CL.ClassLists.VenueList GetVenue()
        {
            try
            {
                VL = new TimeTable_CL.ClassLists.VenueList();

                return VL;
            }
            catch (Exception ex) { return null; }
        }

        public void AddVenue(int VenueID, string SF, int StudentCap)
        {
            try
            {
                VL = new TimeTable_CL.ClassLists.VenueList();
                TimeTable_CL.Classes.Venue aNewVenue = new TimeTable_CL.Classes.Venue(0, SF, StudentCap);
                VL.InsertVenues(aNewVenue);

                VL.SaveVenuesChanges();
            }
            catch (Exception ex)
            {

            }
        }

        public void UpdateVenue(int VenueID, string SF, int StudentCap)
        {
            try
            {
                VL = new TimeTable_CL.ClassLists.VenueList();
                TimeTable_CL.Classes.Venue aUpdateVenue = new TimeTable_CL.Classes.Venue(VenueID, SF, StudentCap);
                VL.UpdateVenues(aUpdateVenue);

                VL.SaveVenuesChanges();
            }
            catch (Exception ex)
            {

            }
        }

        public void DeleteVenue(int VenueID, string SF, int StudentCap)
        {
            TimeTable_CL.Classes.Venue aDeleteVenue = new TimeTable_CL.Classes.Venue(VenueID, SF, StudentCap);

            VL.DeleteVenues(aDeleteVenue);
        }

        #endregion

        public string GetData(int value)
        {
            return string.Format("You entered: {0}", value);
        }

        public CompositeType GetDataUsingDataContract(CompositeType composite)
        {
            if (composite == null)
            {
                throw new ArgumentNullException("composite");
            }
            if (composite.BoolValue)
            {
                composite.StringValue += "Suffix";
            }
            return composite;
        }
    }
}
